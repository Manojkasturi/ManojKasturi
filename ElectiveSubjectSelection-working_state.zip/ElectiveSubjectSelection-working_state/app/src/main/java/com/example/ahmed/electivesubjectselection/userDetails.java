package com.example.ahmed.electivesubjectselection;

/**
 * Created by Ahmed on 2/12/2018.
 */

public class userDetails {
    public String userRoll;
    public String userEmail;
    public String userName;
    public String options;


    public userDetails(String userRoll, String userEmail,String userName,String options) {
        this.userRoll = userRoll;
        this.userEmail = userEmail;
        this.userName = userName;
        this.options=options;
    }
}


