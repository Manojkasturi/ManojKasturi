package com.example.ahmed.electivesubjectselection;

import android.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class OptionsCompletedActivity extends AppCompatActivity {

    ActionBar actionBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options_completed);


    }


}
