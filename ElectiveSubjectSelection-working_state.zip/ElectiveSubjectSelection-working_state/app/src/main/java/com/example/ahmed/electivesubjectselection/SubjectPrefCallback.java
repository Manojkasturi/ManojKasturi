package com.example.ahmed.electivesubjectselection;

/**
 * Created by Ahmed on 3/17/2018.
 */

public interface SubjectPrefCallback {
    void isPrefSubInserted(Boolean status);
}
