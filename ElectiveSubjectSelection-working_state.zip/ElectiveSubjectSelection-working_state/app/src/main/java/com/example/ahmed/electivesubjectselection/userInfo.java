package com.example.ahmed.electivesubjectselection;

/**
 * Created by Ahmed on 2/16/2018.
 */

public class userInfo {
    private String userRoll;
    private String userEmail;

    public userInfo() {
    }

    public String getUserRoll() {
        return userRoll;
    }

    public void setUserRoll(String userRoll) {
        this.userRoll = userRoll;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
