package com.example.ahmed.electivesubjectselection;

import android.annotation.SuppressLint;

/**
 * Created by Ahmed on 3/12/2018.
 */

public class MyConstants {
    @SuppressLint("AuthLeak")
    final static String url= "jdbc:mysql://us-cdbr-iron-east-05.cleardb.net/heroku_87971fd69afef51?reconnect=true";
    final static String user ="be80f325ec8c05";
    final static String password = "db13dfda";
    final static String classes = "com.mysql.jdbc.Driver";
    final static String SELECT_PREF = "--Select Preferences--";
}
